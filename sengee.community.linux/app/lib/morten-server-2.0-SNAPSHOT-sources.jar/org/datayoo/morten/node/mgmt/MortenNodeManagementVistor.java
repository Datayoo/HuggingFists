package org.datayoo.morten.node.mgmt;

import org.datayoo.morten.node.domain.MortenNode;

public interface MortenNodeManagementVistor {

  boolean registable(MortenNode mortenNode);
}
