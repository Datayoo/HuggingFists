package org.datayoo.morten.node.domain;

import org.datayoo.domain.core.Resource;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "MORTEN_NODE",
    indexes = { @Index(name = "IDX_MORTEN_NODE_ID", columnList = "RES_ID"),
    })
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class MortenNode extends Resource {

  @Column(name = "IP_ADDR", length = 64)
  protected String ipAddress;

  @Column(name = "LOCATION", length = 256)
  protected String location;

  @OneToMany(cascade = CascadeType.REMOVE, fetch = FetchType.LAZY)
  @JoinColumn(name = "NODE_ID")
  protected Set<MortenFlow> mortenFlows;

  public String getIpAddress() {
    return ipAddress;
  }

  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public Set<MortenFlow> getMortenFlows() {
    return mortenFlows;
  }

  public void setMortenFlows(Set<MortenFlow> mortenFlows) {
    this.mortenFlows = mortenFlows;
  }
}
