package org.datayoo.morten.node.domain;

import org.datayoo.domain.core.Resource;

import javax.persistence.*;

@Entity
@Table(name = "MORTEN_FLOW",
    indexes = { @Index(name = "IDX_MORTEN_FLOW_ID", columnList = "RES_ID"),
    })
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class MortenFlow extends Resource {

  @Lob
  @Basic(fetch = FetchType.LAZY)
//  @Column(name = "CONF", columnDefinition = "LONGTEXT", nullable = true)
  @Column(name = "CONF",nullable = true)
  protected String configuration;

  @ManyToOne
  @JoinColumn(name = "NODE_ID")
  protected MortenNode owner;

  public String getConfiguration() {
    return configuration;
  }

  public void setConfiguration(String configuration) {
    this.configuration = configuration;
  }

  public MortenNode getOwner() {
    return owner;
  }

  public void setOwner(MortenNode owner) {
    this.owner = owner;
  }
}
