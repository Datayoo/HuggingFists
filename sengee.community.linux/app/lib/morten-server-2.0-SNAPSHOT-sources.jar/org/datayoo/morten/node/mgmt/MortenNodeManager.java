package org.datayoo.morten.node.mgmt;

import org.datayoo.base.biztypes.range.IpAddressRangable;
import org.datayoo.morten.node.domain.MortenFlow;
import org.datayoo.morten.node.domain.MortenNode;
import org.datayoo.morten.node.dto.NodeLoad;

import java.util.List;

public interface MortenNodeManager {

  void addAcceptableIpRange(IpAddressRangable ipAddressRangable);

  boolean removeAcceptableIpRange(IpAddressRangable ipAddressRangable);

  List<MortenNode> getAllMortenNodes();

  MortenNode getMortenNode(String nodeId);

  List<MortenFlow> getMortenFlows(String nodeId);

  List<NodeLoad> getAllOnlineNodeLoads();

  NodeImage getOnlineNode(String nodeId);

  List<NodeImage> getAllOnlineNode();

  NodeLoad getOnlineNodeLoad(String nodeId);

  MortenFlow addMortenFlow(String nodeId, String flowName,
      String flowConfiguration);

  MortenFlow addMortenFlow(MortenFlow mortenFlow);

  void updateMortenNode(MortenNode mortenNode);

  void updateMortenFlow(MortenFlow mortenFlow);

  void removeMortenNode(String nodeId);

  void removeMortenFlow(String flowId);

  void notify(String notification, Object body);

  void setManagementVistor(MortenNodeManagementVistor managementVistor);
}
