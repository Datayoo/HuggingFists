package org.datayoo.morten.node.mgmt;

import org.datayoo.flowx.metadata.FlowNodeMetadata;
import org.datayoo.flowx.util.FlowMetadataUtils;
import org.datayoo.lang.util.ExceptionUtils;
import org.datayoo.morten.exception.MortenRuntimeException;
import org.datayoo.morten.node.NodePropsHelper;
import org.datayoo.morten.node.domain.MortenFlow;
import org.datayoo.morten.node.domain.MortenNode;
import org.datayoo.morten.node.dto.NodeBean;
import org.datayoo.morten.node.repository.MortenFlowRepository;
import org.datayoo.morten.node.repository.MortenNodeRepository;
import org.datayoo.morten.node.service.NodeConfigurationService;
import org.datayoo.util.xml.XmlAccessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedList;
import java.util.List;

public class MortenNodeConfigurationService
    implements NodeConfigurationService {

  @Autowired
  protected MortenJpaNodeManager mortenNodeManager;
  @Autowired
  protected MortenNodeRepository mortenNodeRepository;
  @Autowired
  protected MortenFlowRepository mortenFlowRepository;

  @Override
  public boolean isRegisted(String nodeId) {
    MortenNode mortenNode = mortenNodeManager.getMortenNode(nodeId);
    return mortenNode == null ? false : true;
  }

  @Override
  @Transactional
  public void registNode(NodeBean nodeBean, String configuration) {
    MortenNode mortenNode = createMortenNode(nodeBean);
    try {
      List<FlowNodeMetadata> flowNodeMetadatas = FlowMetadataUtils
          .loadFlowNodeMetadatasFromString(configuration);
      for (FlowNodeMetadata flowNodeMetadata : flowNodeMetadatas) {
        createMortenFlow(flowNodeMetadata, mortenNode);
      }
    } catch (Exception e) {
      mortenNodeManager.removeMortenNode(mortenNode.getId());
      throw new MortenRuntimeException(e.getMessage(), e);
    }
  }

  protected MortenNode createMortenNode(NodeBean nodeBean) {
    MortenNode mortenNode = new MortenNode();
    try {
      mortenNode.setId(nodeBean.getId());
      mortenNode.setName(nodeBean.getName());
      mortenNode.setIpAddress(nodeBean.getIpAddress().toString());
      mortenNode.setLocation(nodeBean.getLocation());
      mortenNode.setTags(NodePropsHelper.tags2String(nodeBean.getTags()));
      return mortenNodeRepository.saveAndFlush(mortenNode);
    } finally {
      mortenNodeManager.updateNodeImage(mortenNode);
    }
  }

  protected MortenFlow createMortenFlow(FlowNodeMetadata flowNodeMetadata,
      MortenNode mortenNode) throws XmlAccessException {
    MortenFlow mortenflow = new MortenFlow();
    mortenflow.setName(flowNodeMetadata.getName());
    mortenflow.setOwner(mortenNode);
    mortenflow.setConfiguration(
        FlowMetadataUtils.flowNodeMetadata2String(flowNodeMetadata));
    return mortenFlowRepository.saveAndFlush(mortenflow);
  }

  @Override
  public String getConfiguration(String nodeId) {
    List<MortenFlow> mortenFlows = mortenFlowRepository
        .getMortenFlowsByOwnerId(nodeId);
    List<FlowNodeMetadata> flowNodeMetadatas = new LinkedList<FlowNodeMetadata>();
    try {
      for (MortenFlow mortenFlow : mortenFlows) {
        FlowNodeMetadata flowNodeMetadata = FlowMetadataUtils
            .loadFlowNodeMetadataFromString(mortenFlow.getConfiguration());
        flowNodeMetadatas.add(flowNodeMetadata);
      }
      return FlowMetadataUtils.flowNodeMetadatas2String(flowNodeMetadatas);
    } catch (XmlAccessException e) {
      throw new MortenRuntimeException(e.getMessage(), e);
    }
  }

  @Override
  @Transactional
  public void setConfiguration(String nodeId, String configuration) {
    try {
      mortenFlowRepository.deleteMortenFlowsByOwnerId(nodeId);
      List<FlowNodeMetadata> flowNodeMetadatas = FlowMetadataUtils
          .loadFlowNodeMetadatasFromString(configuration);
      for (FlowNodeMetadata flowNodeMetadata : flowNodeMetadatas) {
        createMortenFlow(flowNodeMetadata, mortenNodeRepository.getOne(nodeId));
      }
    } catch (Exception e) {
      String error = String.format("%s:%s", e.getClass().getName(),
          ExceptionUtils.stackTrace2String(e));
      throw new MortenRuntimeException(error);
    }
  }
}
