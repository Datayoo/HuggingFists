package org.datayoo.morten.node.branch;

public class MortenBranch {
}
