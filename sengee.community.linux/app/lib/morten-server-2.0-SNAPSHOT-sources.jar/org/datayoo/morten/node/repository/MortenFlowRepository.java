package org.datayoo.morten.node.repository;

import org.datayoo.morten.node.domain.MortenFlow;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MortenFlowRepository extends JpaRepository<MortenFlow, String>,
    JpaSpecificationExecutor<MortenFlow> {
  //  @Query(value = "select pc from PlatformCategory pc where pc.parent.id = ?1 order by ordinal")

  List<MortenFlow> getMortenFlowsByOwnerId(String nodeId);

  @Modifying
  @Query(value = "delete from MortenFlow  where owner.id=?1")
  void deleteMortenFlowsByOwnerId(String nodeId);
}
