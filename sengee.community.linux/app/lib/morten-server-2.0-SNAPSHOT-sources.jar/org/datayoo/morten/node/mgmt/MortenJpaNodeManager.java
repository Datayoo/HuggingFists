package org.datayoo.morten.node.mgmt;

import org.apache.commons.lang3.Validate;
import org.datayoo.base.biztypes.range.IpAddressRangable;
import org.datayoo.base.io.DefaultResourceLoader;
import org.datayoo.base.io.Resource;
import org.datayoo.base.io.ResourceLoader;
import org.datayoo.morten.exception.MortenRuntimeException;
import org.datayoo.morten.exception.MortenServiceException;
import org.datayoo.morten.mortise.MortenEvent;
import org.datayoo.morten.mortise.MortenEventListener;
import org.datayoo.morten.mortise.MortenEventMortise;
import org.datayoo.morten.mortise.ServicesLookupMortise;
import org.datayoo.morten.node.NodePropsHelper;
import org.datayoo.morten.node.domain.MortenFlow;
import org.datayoo.morten.node.domain.MortenNode;
import org.datayoo.morten.node.dto.NodeLoad;
import org.datayoo.morten.node.leaf.MortenBreakedEvent;
import org.datayoo.morten.node.leaf.MortenConnectedEvent;
import org.datayoo.morten.node.repository.MortenFlowRepository;
import org.datayoo.morten.node.repository.MortenNodeRepository;
import org.datayoo.morten.node.service.NodeConfigurationService;
import org.datayoo.morten.node.service.NodeNotificationMonitorService;
import org.datayoo.morten.node.service.NodeTagService;
import org.datayoo.morten.node.util.MortenLoad;
import org.datayoo.yee.channel.HeartbeatListener;
import org.datayoo.yee.channel.YeeConnectionListener;
import org.datayoo.yee.channel.YeeServerChannel;
import org.datayoo.yee.exception.CommunicationException;
import org.datayoo.yee.exception.RegistrationException;
import org.datayoo.yee.factory.YeeChannelType;
import org.datayoo.yee.factory.YeeFactory;
import org.datayoo.yee.rpc.ServiceType;
import org.datayoo.yee.rpc.server.YeeServerServiceGate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.*;
import java.util.regex.Pattern;

public class MortenJpaNodeManager
    implements MortenNodeManager, MortenServiceManager, ServicesLookupMortise,
    NodeTagService, MortenEventMortise {

  protected static final Logger logger = LoggerFactory.getLogger(
      MortenJpaNodeManager.class);

  protected String id;

  protected Properties properties;

  protected YeeServerChannel yeeChannel;

  protected YeeServerServiceGate serverServiceGate;
  @Autowired
  protected MortenNodeRepository mortenNodeRepository;
  @Autowired
  protected MortenFlowRepository mortenFlowRepository;

  protected boolean initialized = false;

  protected Map<String, NodeImage> nodeMap = new HashMap<>();

  @Autowired
  protected NodeConfigurationService nodeConfigurationService;

  protected MortenNodeNotificationService notificationService;

  protected List<MortenEventListener> eventListeners = new LinkedList<>();

  protected MortenNodeManagementVistor managementVistor;

  public MortenJpaNodeManager(String propsFile) throws IOException {
    Validate.notEmpty(propsFile, "propsFile is empty!");
    properties = loadProperties(propsFile);
    id = NodePropsHelper.getNodeId(properties);
  }

  protected Properties loadProperties(String propsFile) throws IOException {
    ResourceLoader resourceLoader = new DefaultResourceLoader();
    Resource resource = resourceLoader.getResource(propsFile);
    Properties props = new Properties();
    props.load(resource.getInputStream());
    return props;
  }

  public MortenJpaNodeManager(Properties properties) {
    Validate.notEmpty(properties, "properties is empty!");
    id = NodePropsHelper.getNodeId(properties);
    this.properties = properties;
  }

  @PostConstruct
  public synchronized void initialize() {
    if (initialized)
      return;
    try {
      initializeCommunication();
      initializeServices();
      initialized = true;
    } catch (Throwable t) {
      initialized = false;
      throw new MortenRuntimeException(t.getMessage(), t);
    }
  }

  protected void initializeCommunication() throws CommunicationException {
    YeeChannelType yeeChannelType = NodePropsHelper.getContainerCommunicationType(
        properties, YeeChannelType.Netty.name());
    yeeChannel = YeeFactory.createYeeServerChannel(yeeChannelType, id,
        properties);
    serverServiceGate = new YeeServerServiceGate(yeeChannel, properties);
    serverServiceGate.setConnectionListener(new InnerConnectionListener());
    serverServiceGate.open();

  }

  protected void initializeServices() throws RegistrationException {
    // 注册配置服务
    serverServiceGate.registService(NodeConfigurationService.class,
        nodeConfigurationService, ServiceType.CLUSTER);
    notificationService = new MortenNodeNotificationService(serverServiceGate);
    // 注册通知注册服务
    serverServiceGate.registService(NodeNotificationMonitorService.class,
        notificationService, ServiceType.CLUSTER);
    serverServiceGate.registService(ServicesLookupMortise.class, this,
        ServiceType.CLUSTER);
    // 注册TAG服务
    serverServiceGate.registService(NodeTagService.class, this,
        ServiceType.CLUSTER);
  }

  @PreDestroy
  public synchronized void destroy() {
    if (!initialized) {
      return;
    }
    try {
      destroyCommunication();
      initialized = false;
    } catch (Throwable t) {
      throw new MortenRuntimeException(t.getMessage(), t);
    } finally {
      synchronized (nodeMap) {
        nodeMap.clear();
      }
      synchronized (eventListeners) {
        eventListeners.clear();
      }
    }
  }

  protected void destroyCommunication() throws CommunicationException {
    try {
      if (serverServiceGate != null) {
        serverServiceGate.close();
      }
    } finally {
      if (yeeChannel != null) {
        yeeChannel.close();
        yeeChannel = null;
      }
    }
  }

  public void addAcceptableIpRange(IpAddressRangable ipAddressRangable) {
    yeeChannel.addAcceptableIpRange(ipAddressRangable);
  }

  public boolean removeAcceptableIpRange(IpAddressRangable ipAddressRangable) {
    return yeeChannel.removeAcceptableIpRange(ipAddressRangable);
  }

  @Override
  public List<MortenNode> getAllMortenNodes() {
    return mortenNodeRepository.findAll();
  }

  @Override
  public MortenNode getMortenNode(String nodeId) {
    return mortenNodeRepository.findById(nodeId).orElse(null);
  }

  @Override
  public List<MortenFlow> getMortenFlows(String nodeId) {
    return mortenFlowRepository.getMortenFlowsByOwnerId(nodeId);
  }

  @Override
  public List<NodeLoad> getAllOnlineNodeLoads() {
    List<NodeLoad> nodeLoads = new LinkedList<NodeLoad>();
    for (NodeImage nodeImage : nodeMap.values()) {
      nodeLoads.add(nodeImage.getNodeLoad());
    }
    return nodeLoads;
  }

  @Override
  public NodeLoad getOnlineNodeLoad(String nodeId) {
    NodeImage nodeImage = nodeMap.get(nodeId);
    if (nodeImage != null)
      return nodeImage.getNodeLoad();
    return null;
  }

  @Override
  public NodeImage getOnlineNode(String nodeId) {
    return nodeMap.get(nodeId);
  }

  @Override
  public List<NodeImage> getAllOnlineNode() {
    return new LinkedList<>(nodeMap.values());
  }

  @Override
  @Transactional
  public MortenFlow addMortenFlow(String nodeId, String flowNodeName,
      String flowConfiguration) {
    MortenFlow mortenFlow = new MortenFlow();
    mortenFlow.setName(flowNodeName);
    mortenFlow.setConfiguration(flowConfiguration);
    mortenFlow.setOwner(mortenNodeRepository.getOne(nodeId));
    return mortenFlowRepository.save(mortenFlow);
  }

  @Override
  @Transactional
  public MortenFlow addMortenFlow(MortenFlow mortenFlow) {
    return mortenFlowRepository.save(mortenFlow);
  }

  @Override
  @Transactional
  public void updateMortenNode(MortenNode mortenNode) {
    mortenNodeRepository.saveAndFlush(mortenNode);
    updateNodeImage(mortenNode);
  }

  @Override
  @Transactional
  public void updateMortenFlow(MortenFlow mortenFlow) {
    mortenFlowRepository.saveAndFlush(mortenFlow);
  }

  @Override
  @Transactional
  public void removeMortenNode(String nodeId) {
    mortenFlowRepository.deleteMortenFlowsByOwnerId(nodeId);
    mortenNodeRepository.deleteById(nodeId);
  }

  @Override
  @Transactional
  public void removeMortenFlow(String flowId) {
    mortenFlowRepository.deleteById(flowId);
  }

  @Override
  public void registService(Class<?> serviceInterface, Object serviceSupplier,
      ServiceType serviceType) throws MortenServiceException {
    try {
      serverServiceGate.registService(serviceInterface, serviceSupplier,
          serviceType);
    } catch (RegistrationException e) {
      throw new MortenServiceException(e);
    }
  }

  @Override
  public void registNamedService(String serviceName, Class<?> serviceInterface,
      Object serviceSupplier) throws MortenServiceException {
    try {
      serverServiceGate.registNamedService(serviceName, serviceInterface,
          serviceSupplier);
    } catch (RegistrationException e) {
      throw new MortenServiceException(e);
    }
  }

  @Override
  public boolean unregistService(Class<?> serviceInterface,
      Object serviceSupplier) throws MortenServiceException {
    try {
      return serverServiceGate.unregistService(serviceInterface,
          serviceSupplier);
    } catch (RegistrationException e) {
      throw new MortenServiceException(e);
    }
  }

  @Override
  public boolean unregistNamedService(String serviceName)
      throws MortenServiceException {
    try {
      return serverServiceGate.unregistNamedService(serviceName);
    } catch (RegistrationException e) {
      throw new MortenServiceException(e);
    }
  }

  @Override
  public Object lookup(Class<?> serviceInterface)
      throws MortenServiceException {
    try {
      return serverServiceGate.lookup(serviceInterface);
    } catch (CommunicationException e) {
      throw new MortenServiceException(e);
    }
  }

  @Override
  public Object lookup(String destinationId, Class<?> serviceInterface) {
    return serverServiceGate.lookup(destinationId, serviceInterface);
  }

  @Override
  public Object lookupNamedService(String serviceName)
      throws MortenServiceException {
    try {
      return serverServiceGate.lookupNamedService(serviceName);
    } catch (CommunicationException e) {
      throw new MortenServiceException(e);
    }
  }

  @Override
  public Set<String> lookupByTags(Class<?> serviceInterface,
      Map<String, String[]> tags) {
    Set<String> ids = serverServiceGate.lookupAllDestinations(serviceInterface);
    if (ids == null || ids.size() == 0) {
      return new HashSet<>();
    }
    ids = new HashSet<>(ids);
    if (tags == null || tags.size() < 1) {
      return ids;
    }
    for (Iterator<String> iterator = ids.iterator(); iterator.hasNext(); ) {
      String id = iterator.next();
      NodeImage nodeImage = nodeMap.get(id);
      if (nodeImage == null) {
        iterator.remove();
        continue;
      }
      boolean contains = true;
      //tags:所有key的tags需要匹配
      for (Map.Entry<String, String[]> entry : tags.entrySet()) {
        //节点上的key对应的tags
        String[] tagValues = nodeImage.getTags().get(entry.getKey());
        if (!isMatch(entry.getValue(), tagValues)) {
          contains = false;
          break;
        }
      }
      if (!contains) {
        iterator.remove();
      }
    }
    return ids;
  }

  /**
   * @param value      : 输入tags
   * @param tagValues: 节点的tags
   * @return: value的所有值在tagValues中找到返回true
   */
  protected boolean isMatch(String[] value, String[] tagValues) {
    if (value == null || tagValues == null)
      return false;
    for (int i = 0; i < value.length; i++) {
      int index = Arrays.binarySearch(tagValues, value[i]);
      if (index == -1)
        return false;
    }
    return true;
  }

  @Override
  public Set<String> lookupByNamePattern(Class<?> serviceInterface,
      String namePattern) {
    Set<String> ids = serverServiceGate.lookupAllDestinations(serviceInterface);
    if (ids == null || ids.size() == 0) {
      return new HashSet<>();
    }
    ids = new HashSet<>(ids);
    Pattern pattern = Pattern.compile(namePattern);
    for (Iterator<String> iterator = ids.iterator(); iterator.hasNext(); ) {
      String id = iterator.next();
      NodeImage nodeImage = nodeMap.get(id);
      if (nodeImage == null || !pattern.matcher(nodeImage.getName())
          .matches()) {
        iterator.remove();
        continue;
      }
    }
    return ids;
  }

  @Override
  public Set<String> lookupAllDestinations(Class<?> serviceInterface) {
    return serverServiceGate.lookupAllDestinations(serviceInterface);
  }

  @Override
  public Object delegate(Object callbackObject, Class<?> delegatedClass) {
    return serverServiceGate.delegate(callbackObject, delegatedClass);
  }

  @Override
  public Object undelegate(Object callbackObject) {
    return serverServiceGate.undelegate(callbackObject);
  }

  public void updateNodeImage(MortenNode mortenNode) {
    if (managementVistor != null) {
      if (!managementVistor.registable(mortenNode)) {
        return;
      }
    }
    NodeImage nodeImage;
    synchronized (nodeMap) {
      nodeImage = nodeMap.get(mortenNode.getId());
    }
    if (nodeImage == null)
      return;
    nodeImage.setName(mortenNode.getName());
    nodeImage.setLocation(mortenNode.getLocation());
    if (mortenNode.getTags() != null)
      nodeImage.setTags(NodePropsHelper.string2Tags(mortenNode.getTags()));
  }

  @Override
  public void notify(String notification, Object body) {
    notificationService.notify(notification, body);
  }

  @Override
  public String[] setTag(String nodeId, String tag, String[] value) {
    NodeImage nodeImage;
    synchronized (nodeMap) {
      nodeImage = nodeMap.get(nodeId);
    }
    if (nodeImage == null)
      throw new IllegalStateException(
          String.format("There is no node '%s'!", nodeId));
    return nodeImage.getTags().put(tag, value);
  }

  @Override
  public String[] getTag(String nodeId, String tag) {
    NodeImage nodeImage;
    synchronized (nodeMap) {
      nodeImage = nodeMap.get(nodeId);
    }
    if (nodeImage == null)
      throw new IllegalStateException(
          String.format("There is no node '%s'!", nodeId));
    return nodeImage.getTags().get(tag);
  }

  @Override
  public String[] removeTag(String nodeId, String tag) {
    NodeImage nodeImage;
    synchronized (nodeMap) {
      nodeImage = nodeMap.get(nodeId);
    }
    if (nodeImage == null)
      throw new IllegalStateException(
          String.format("There is no node '%s'!", nodeId));
    return nodeImage.getTags().remove(tag);
  }

  public String getId() {
    return id;
  }

  public void setMortenNodeRepository(
      MortenNodeRepository mortenNodeRepository) {
    this.mortenNodeRepository = mortenNodeRepository;
  }

  public void setMortenFlowRepository(
      MortenFlowRepository mortenFlowRepository) {
    this.mortenFlowRepository = mortenFlowRepository;
  }

  @Override
  public void setManagementVistor(MortenNodeManagementVistor managementVistor) {
    this.managementVistor = managementVistor;
  }

  @Override
  public void registEventListener(MortenEventListener eventListener) {
    synchronized (eventListeners) {
      eventListeners.add(eventListener);
    }
  }

  @Override
  public void unregistEventListener(MortenEventListener eventListener) {
    synchronized (eventListeners) {
      eventListeners.remove(eventListener);
    }
  }

  protected class InnerConnectionListener implements YeeConnectionListener {
    @Override
    public void onConnected(String nodeId) {
      NodeImage nodeImage = new NodeImage(nodeId);
      synchronized (nodeMap) {
        nodeMap.put(nodeId, nodeImage);
      }
      nodeImage.setIpAddress(yeeChannel.getPeerIp(nodeId));
      // 若获得mortenNode时间太长，可能会导致连接建立失败
      MortenNode mortenNode = getMortenNode(nodeId);
      if (mortenNode != null) {
        nodeImage.setName(mortenNode.getName());
        nodeImage.setLocation(mortenNode.getLocation());
        if (mortenNode.getTags() != null)
          nodeImage.setTags(NodePropsHelper.string2Tags(mortenNode.getTags()));
      }
      onMortenEvent(new MortenConnectedEvent());
    }

    @Override
    public void onBreaked(String nodeId) {
      synchronized (nodeMap) {
        nodeMap.remove(nodeId);
        // 删除节点监听的通知
        notificationService.unMonitorNotifications(nodeId, null);
      }
      onMortenEvent(new MortenBreakedEvent(nodeId));
    }

    protected void onMortenEvent(MortenEvent event) {
      synchronized (eventListeners) {
        for (MortenEventListener listener : eventListeners) {
          try {
            listener.onEvent(event);
          } catch (Throwable t) {
            logger.warn(t.getMessage(), t);
          }
        }
      }
    }
  }

  protected class InnerHeartbeatListener implements HeartbeatListener {

    @Override
    public void onPayload(String sourceId, byte[] bytes) {
      if (bytes.length == 6)  // "mirror".bytes(),参见ServiceMirror
        return;
      NodeLoad nodeLoad = MortenLoad.convert2(bytes);
      synchronized (nodeMap) {
        NodeImage nodeImage = nodeMap.get(sourceId);
        if (nodeImage != null)
          nodeImage.setNodeLoad(nodeLoad);
      }
    }
  }
}
