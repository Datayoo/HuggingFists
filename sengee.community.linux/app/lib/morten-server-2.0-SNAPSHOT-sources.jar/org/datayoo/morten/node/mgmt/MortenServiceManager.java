package org.datayoo.morten.node.mgmt;

import org.datayoo.morten.exception.MortenServiceException;
import org.datayoo.yee.rpc.ServiceType;

public interface MortenServiceManager {
  void registService(Class<?> serviceInterface, Object serviceSupplier,
      ServiceType serviceType) throws MortenServiceException;

  void registNamedService(String serviceName, Class<?> serviceInterface,
      Object serviceSupplier) throws MortenServiceException;

  boolean unregistService(Class<?> serviceInterface, Object serviceSupplier)
      throws MortenServiceException;

  boolean unregistNamedService(String serviceName) throws MortenServiceException;

  Object lookup(Class<?> serviceInterface) throws MortenServiceException;

  Object lookup(String destinationId, Class<?> serviceInterface);

  Object lookupNamedService(String serviceName) throws MortenServiceException;

  Object delegate(Object callbackObject,Class<?> delegatedClass);

  Object undelegate(Object callbackObject);

}
