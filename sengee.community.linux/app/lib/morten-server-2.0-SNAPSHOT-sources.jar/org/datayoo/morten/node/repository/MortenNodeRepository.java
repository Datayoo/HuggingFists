package org.datayoo.morten.node.repository;

import org.datayoo.morten.node.domain.MortenNode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface MortenNodeRepository extends JpaRepository<MortenNode, String>,
    JpaSpecificationExecutor<MortenNode> {

}
