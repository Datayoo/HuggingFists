package org.datayoo.morten.node.mgmt;

import org.datayoo.morten.mortise.NotificationListener;
import org.datayoo.morten.node.service.NodeNotificationMonitorService;
import org.datayoo.morten.node.service.NodeNotificationService;
import org.datayoo.yee.rpc.server.YeeServerServiceGate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class MortenNodeNotificationService
    implements NodeNotificationMonitorService {

  protected static final Logger logger = LoggerFactory
      .getLogger(MortenNodeNotificationService.class);

  protected YeeServerServiceGate serverServiceGate;

  protected Map<String, Set<String>> notificationCache = new HashMap<String, Set<String>>();

  public MortenNodeNotificationService(YeeServerServiceGate serverServiceGate) {
    this.serverServiceGate = serverServiceGate;
  }

  @Override
  public synchronized void monitorNotifications(String nodeId,
      String[] notifications) {
    for (int i = 0; i < notifications.length; i++) {
      Set<String> nodeIds = notificationCache.get(notifications[i]);
      if (nodeIds == null) {
        nodeIds = new HashSet<>();
        notificationCache.put(notifications[i], nodeIds);
      }
      nodeIds.add(nodeId);
    }
  }

  @Override
  public synchronized void unMonitorNotifications(String nodeId,
      String[] notifications) {
    if (notifications == null) {
      for (Iterator<Map.Entry<String, Set<String>>> it = notificationCache
          .entrySet().iterator(); it.hasNext(); ) {
        Map.Entry<String, Set<String>> entry = it.next();
        entry.getValue().remove(nodeId);
        if (entry.getValue().size() == 0)
          it.remove();
      }
    } else {
      for (String notification : notifications) {
        Set<String> nodeIds = notificationCache.get(notification);
        if (nodeIds == null) {
          continue;
        }
        nodeIds.remove(nodeId);
        if (nodeIds.size() == 0) {
          notificationCache.remove(nodeId);
        }
      }
    }
  }

  @Override
  public synchronized void notify(String notification, Object body) {
    Set<String> nodeIds = notificationCache.get(notification);
    if (nodeIds == null)
      return;
    for (String nodeId : nodeIds) {
      NodeNotificationService nodeNotificationService = (NodeNotificationService) serverServiceGate
          .lookup(nodeId, NodeNotificationService.class);
      try {
        nodeNotificationService.onNotification(notification, body);
      } catch (Throwable t) {
        logger.warn(String
                .format("Notify '%s' to node '%s' failed!", notification, nodeId),
            t);
      }
    }
  }
}
