package org.datayoo.morten.node.mgmt;

import org.apache.commons.lang3.Validate;
import org.datayoo.base.biztypes.IpAddress;
import org.datayoo.morten.node.dto.NodeBean;
import org.datayoo.morten.node.dto.NodeLoad;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class NodeImage implements Serializable {

  protected String id;

  protected String name;

  protected IpAddress ipAddress;

  protected String location;

  protected Map<String, String[]> tags = new HashMap<>();

  protected NodeLoad nodeLoad;

  public NodeImage(String id) {
    Validate.notEmpty(id, "id is empty!");
    this.id = id;
  }

  public NodeImage(NodeBean nodeBean) {
    this(nodeBean.getId());
    this.name = nodeBean.getName();
    this.tags.putAll(nodeBean.getTags());
  }

  public String getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public IpAddress getIpAddress() {
    return ipAddress;
  }

  public void setIpAddress(IpAddress ipAddress) {
    this.ipAddress = ipAddress;
  }

  public String getLocation() {
    return location;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public Map<String, String[]> getTags() {
    return tags;
  }

  public void setTags(Map<String, String[]> tags) {
    if (tags == null)
      tags = new HashMap<>();
    this.tags = tags;
  }

  public NodeLoad getNodeLoad() {
    return nodeLoad;
  }

  public void setNodeLoad(NodeLoad nodeLoad) {
    this.nodeLoad = nodeLoad;
  }
}
